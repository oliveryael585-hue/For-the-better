FOR THE BETTER — iPhone Safari version

This package is a Progressive Web App (PWA). It needs to be published at an HTTPS address once.
After that, open the address in Safari and choose Share > Add to Home Screen.

EASIEST PUBLISH OPTION: GitHub Pages
1. On a computer, sign in to GitHub and create a new public repository named `for-the-better`.
2. Upload the four files in this folder to the repository's top level:
   index.html, manifest.webmanifest, sw.js, icon.svg
3. In the repository, open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select the `main` branch and `/ (root)`, then Save.
6. Wait for GitHub Pages to show the published HTTPS URL.
7. On your iPhone, open that URL in Safari.
8. Tap Share > Add to Home Screen > Add.

The app stores entries in the browser's local storage on that device. It does not automatically sync between your iPhone and computer. Avoid clearing Safari website data unless you have exported a backup from the app.
